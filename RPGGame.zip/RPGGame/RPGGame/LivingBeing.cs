﻿namespace RPGGame
{
    public abstract class LivingBeing
    {
        public string Name;
        public int Level;
        public int Health;
        public int Attack;
        public int Defense;
        public string Technique;
    }
}
